package com.stride.data;

import com.stride.model.Announcement;
import com.stride.model.AttendanceRecord;
import com.stride.model.Room;
import com.stride.model.TimetableEntry;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;

/**
 * SAMPLE data only (no real student, lecturer or college records).
 * Later this whole class is replaced by database queries behind the same service methods.
 */
public final class DummyData {

    private static final String SWD = "CSE305";
    private static final String NET = "CSE310";
    private static final String EMB = "CSE315";
    private static final String SYS = "CSE302";
    private static final String RNI = "CSE206";

    public static final List<Room> ROOMS = List.of(
            new Room("Block A 101", "Block A", 60),
            new Room("Block A 102", "Block A", 60),
            new Room("Block B 204", "Block B", 40),
            new Room("Block B 205", "Block B", 40),
            new Room("Lab 1", "Computer labs", 30),
            new Room("Lab 2", "Computer labs", 30),
            new Room("Lab 3", "Computer labs", 30),
            new Room("Lecture Hall", "Main building", 150));

    public static final List<TimetableEntry> TIMETABLE = List.of(
            e(DayOfWeek.MONDAY, "08:00", "10:00", SYS, "Computer Systems Administration", "Block A 101"),
            e(DayOfWeek.MONDAY, "10:30", "12:30", SWD, "Advanced Web Development with Java", "Lab 2"),
            e(DayOfWeek.MONDAY, "14:00", "16:00", RNI, "Research and Innovation", "Block B 204"),

            e(DayOfWeek.TUESDAY, "08:00", "10:00", SWD, "Advanced Web Development with Java", "Lab 2"),
            e(DayOfWeek.TUESDAY, "10:30", "12:30", NET, "Computer Networks", "Block A 102"),
            e(DayOfWeek.TUESDAY, "13:30", "15:30", EMB, "Embedded Systems", "Lab 1"),

            e(DayOfWeek.WEDNESDAY, "09:00", "11:00", NET, "Computer Networks", "Block A 102"),
            e(DayOfWeek.WEDNESDAY, "11:30", "13:30", SYS, "Computer Systems Administration", "Lab 3"),
            e(DayOfWeek.WEDNESDAY, "14:30", "16:30", RNI, "Research and Innovation", "Block B 204"),

            e(DayOfWeek.THURSDAY, "08:00", "10:00", EMB, "Embedded Systems", "Lab 1"),
            e(DayOfWeek.THURSDAY, "10:30", "12:30", SWD, "Advanced Web Development with Java", "Lab 2"),
            e(DayOfWeek.THURSDAY, "14:00", "16:00", SYS, "Computer Systems Administration", "Block A 101"),

            e(DayOfWeek.FRIDAY, "08:00", "10:00", RNI, "Research and Innovation", "Block B 204"),
            e(DayOfWeek.FRIDAY, "10:30", "12:30", NET, "Computer Networks", "Block A 102"),
            e(DayOfWeek.FRIDAY, "13:00", "15:00", EMB, "Embedded Systems", "Lab 1"),

            e(DayOfWeek.SATURDAY, "09:00", "11:00", SWD, "Advanced Web Development with Java", "Lab 2"));

    public static final List<Announcement> ANNOUNCEMENTS = List.of(
            new Announcement("Examination timetable published",
                    "The examination timetable is now available. Arrive 30 minutes before each paper and bring your student card.",
                    "Registry", "14 Oct 2026"),
            new Announcement("Library hours extended for exams",
                    "The library opens an hour earlier and closes an hour later until the end of the examination period.",
                    "Library", "13 Oct 2026"),
            new Announcement("Lab 2 session moved on Thursday",
                    "The Thursday Advanced Web Development session stays in Lab 2. Bring your laptop and charger.",
                    "Lecturer", "12 Oct 2026"),
            new Announcement("Careers evening for final-year students",
                    "Meet employers and ask about internships. Register at the student support desk.",
                    "Student Support", "9 Oct 2026"));

    public static final List<AttendanceRecord> ATTENDANCE = List.of(
            new AttendanceRecord(RNI, "Research and Innovation", 7, 8),
            new AttendanceRecord(SYS, "Computer Systems Administration", 9, 10),
            new AttendanceRecord(SWD, "Advanced Web Development with Java", 6, 8),
            new AttendanceRecord(NET, "Computer Networks", 10, 10),
            new AttendanceRecord(EMB, "Embedded Systems", 5, 7));

    private DummyData() {
    }

    private static TimetableEntry e(DayOfWeek day, String start, String end,
                                    String code, String name, String room) {
        return new TimetableEntry(day, LocalTime.parse(start), LocalTime.parse(end), code, name, room);
    }
}
