package com.stride.service;

import com.stride.data.DummyData;
import com.stride.model.FreeRoom;
import com.stride.model.Room;
import com.stride.model.TimetableEntry;
import com.stride.model.TodayClass;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Timetable rules: what is on today, and which rooms are free right now. */
public final class ScheduleService {

    public static final LocalTime ROOMS_OPEN = LocalTime.of(7, 0);
    public static final LocalTime ROOMS_CLOSE = LocalTime.of(18, 0);
    private static final DateTimeFormatter HM = DateTimeFormatter.ofPattern("HH:mm");

    private ScheduleService() {
    }

    /** Today's classes in time order, each marked finished, in progress or later. */
    public static List<TodayClass> classesOn(DayOfWeek day, LocalTime now) {
        List<TodayClass> list = new ArrayList<>();
        for (TimetableEntry e : DummyData.TIMETABLE) {
            if (e.getDay() != day) continue;
            TodayClass.Status status = !now.isBefore(e.getEnd()) ? TodayClass.Status.DONE
                    : !now.isBefore(e.getStart()) ? TodayClass.Status.NOW
                    : TodayClass.Status.LATER;
            list.add(new TodayClass(e, status));
        }
        list.sort(Comparator.comparing(TodayClass::getStartText));
        return list;
    }

    public static boolean roomsOpen(LocalTime now) {
        return !now.isBefore(ROOMS_OPEN) && now.isBefore(ROOMS_CLOSE);
    }

    /**
     * A room is free only when no timetable entry overlaps the requested moment.
     * "Free until" is the start of its next booking today, or closing time.
     */
    public static List<FreeRoom> freeRooms(DayOfWeek day, LocalTime now) {
        List<FreeRoom> free = new ArrayList<>();
        if (!roomsOpen(now)) {
            return free;
        }
        LocalTime next = now.withSecond(0).withNano(0);
        for (Room room : DummyData.ROOMS) {
            boolean busy = false;
            LocalTime nextStart = ROOMS_CLOSE;
            for (TimetableEntry e : DummyData.TIMETABLE) {
                if (!e.getRoom().equals(room.getName()) || e.getDay() != day) continue;
                if (e.overlaps(day, next, next.plusMinutes(1))) {
                    busy = true;
                    break;
                }
                if (e.getStart().isAfter(next) && e.getStart().isBefore(nextStart)) {
                    nextStart = e.getStart();
                }
            }
            if (!busy) {
                free.add(new FreeRoom(room.getName(), room.getBuilding(), room.getCapacity(),
                        nextStart.equals(ROOMS_CLOSE) ? "closing time" : HM.format(nextStart)));
            }
        }
        return free;
    }
}
