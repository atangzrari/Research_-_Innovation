package com.stride.service;

import com.stride.model.DemoLogin;
import com.stride.model.Role;
import com.stride.model.User;
import com.stride.security.PasswordHasher;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * Checks sign-ins against a small in-memory directory of DEMO accounts (no real student data).
 * Only password hashes are stored. A database-backed version can replace this class later
 * without touching the controllers.
 */
public final class AccountService {

    private static final class Account {
        final User user;
        final String passwordHash;

        Account(User user, String passwordHash) {
            this.user = user;
            this.passwordHash = passwordHash;
        }
    }

    private static final Map<String, Account> ACCOUNTS = new HashMap<>();

    // Hashed once so that an unknown email costs the same time as a wrong password.
    private static final String DUMMY_HASH = PasswordHasher.hash("not-a-real-password");

    /** Made-up accounts for testing. Only their hashes are kept in ACCOUNTS. */
    private static final List<DemoLogin> DEMO_LOGINS = List.of(
            new DemoLogin(new User(1, "Demo", "Student", "student@stride.test", Role.STUDENT), "student123"),
            new DemoLogin(new User(2, "Demo", "Lecturer", "lecturer@stride.test", Role.LECTURER), "lecturer123"),
            new DemoLogin(new User(3, "Demo", "Administrator", "admin@stride.test", Role.ADMINISTRATOR), "admin123"));

    static {
        for (DemoLogin d : DEMO_LOGINS) {
            add(d.getUser(), d.getPassword());
        }
    }

    private AccountService() {
    }

    private static void add(User user, String password) {
        ACCOUNTS.put(user.getEmail().toLowerCase(Locale.ROOT), new Account(user, PasswordHasher.hash(password)));
    }

    public static String normalise(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
    }

    public static Optional<User> authenticate(String email, String password) {
        Account account = ACCOUNTS.get(normalise(email));
        if (account == null) {
            PasswordHasher.verify(password == null ? "" : password, DUMMY_HASH);
            return Optional.empty();
        }
        return PasswordHasher.verify(password, account.passwordHash)
                ? Optional.of(account.user)
                : Optional.empty();
    }
}
