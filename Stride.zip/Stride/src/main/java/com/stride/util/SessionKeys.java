package com.stride.util;

/** Fixed names for the attributes Stride keeps in the HTTP session. */
public final class SessionKeys {

    /** The signed-in {@link com.stride.model.User}. */
    public static final String USER = "strideUser";

    /** The anti-CSRF token for this session. */
    public static final String CSRF = "strideCsrfToken";

    private SessionKeys() {
    }
}
