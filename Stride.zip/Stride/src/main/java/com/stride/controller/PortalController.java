package com.stride.controller;

import com.stride.data.DummyData;
import com.stride.data.ServiceCatalogue;
import com.stride.model.CampusService;
import com.stride.model.TodayClass;
import com.stride.security.CsrfTokens;
import com.stride.service.ScheduleService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Controller for every signed-in page. Each URL gets the data its view needs, then FORWARDS to the view.
 * Sign-in is checked once, by AuthenticationFilter, before this class runs.
 */
@WebServlet(name = "portalController",
        urlPatterns = {"/dashboard", "/classes", "/notices", "/attendance", "/sites", "/help"})
public class PortalController extends HttpServlet {

    private static final Map<String, String> VIEWS = Map.of(
            "/dashboard", "dashboard",
            "/classes", "classes",
            "/notices", "notices",
            "/attendance", "attendance",
            "/sites", "sites",
            "/help", "help");

    private static final ZoneId CAMPUS_ZONE = ZoneId.of("Africa/Gaborone");
    private static final DateTimeFormatter DATE =
            DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", Locale.ENGLISH);

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String view = VIEWS.get(request.getServletPath());
        if (view == null) {
            response.sendError(404);
            return;
        }

        LocalDateTime now = LocalDateTime.now(CAMPUS_ZONE);
        request.setAttribute("csrfToken", CsrfTokens.token(request.getSession()));
        request.setAttribute("today", DATE.format(now));
        request.setAttribute("greeting", greetingFor(now.getHour()));

        switch (view) {
            case "dashboard": {
                List<TodayClass> classes = ScheduleService.classesOn(now.getDayOfWeek(), now.toLocalTime());
                request.setAttribute("tiles", ServiceCatalogue.all());
                request.setAttribute("classCount", classes.size());
                request.setAttribute("nextClass", firstNotFinished(classes));
                request.setAttribute("latestNotice", DummyData.ANNOUNCEMENTS.get(0));
                break;
            }
            case "classes":
                request.setAttribute("todayClasses",
                        ScheduleService.classesOn(now.getDayOfWeek(), now.toLocalTime()));
                request.setAttribute("freeRooms",
                        ScheduleService.freeRooms(now.getDayOfWeek(), now.toLocalTime()));
                request.setAttribute("roomsOpen", ScheduleService.roomsOpen(now.toLocalTime()));
                break;
            case "notices":
                request.setAttribute("announcements", DummyData.ANNOUNCEMENTS);
                break;
            case "attendance":
                request.setAttribute("attendance", DummyData.ATTENDANCE);
                break;
            case "sites": {
                String query = request.getParameter("q");
                List<CampusService> hits = ServiceCatalogue.search(query);
                request.setAttribute("query", query == null ? "" : query.trim());
                request.setAttribute("services", hits);
                request.setAttribute("total", ServiceCatalogue.all().size());
                break;
            }
            default:
                break;   // help page needs nothing extra
        }

        request.getRequestDispatcher("/WEB-INF/views/" + view + ".jsp").forward(request, response);
    }

    /** The class happening now, or else the next one today; null when nothing is left. */
    static TodayClass firstNotFinished(List<TodayClass> classes) {
        for (TodayClass c : classes) {
            if (c.getStatus() != TodayClass.Status.DONE) {
                return c;
            }
        }
        return null;
    }

    static String greetingFor(int hour) {
        if (hour < 12) return "Good morning";
        if (hour < 18) return "Good afternoon";
        return "Good evening";
    }
}
