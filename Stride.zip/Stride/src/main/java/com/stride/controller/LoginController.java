package com.stride.controller;

import com.stride.data.ServiceCatalogue;
import com.stride.model.User;
import com.stride.security.CsrfTokens;
import com.stride.security.LoginThrottle;
import com.stride.service.AccountService;
import com.stride.util.SessionKeys;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.time.Clock;
import java.time.Duration;
import java.util.Optional;

/**
 * GET  /login: show the sign-in form.
 * POST /login: check CSRF token, throttle, credentials; on success start a fresh session.
 */
@WebServlet(name = "loginController", urlPatterns = "/login")
public class LoginController extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/login.jsp";
    private static final LoginThrottle THROTTLE =
            new LoginThrottle(5, Duration.ofMinutes(5), Clock.systemUTC());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession existing = request.getSession(false);
        if (existing != null && existing.getAttribute(SessionKeys.USER) != null) {
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        showForm(request, response, null, HttpServletResponse.SC_OK);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (!CsrfTokens.isValid(request)) {
            showForm(request, response,
                    "Your sign-in page expired. Try again.", HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String key = AccountService.normalise(email);

        Duration locked = THROTTLE.remainingLock(key);
        if (!locked.isZero()) {
            long minutes = Math.max(1, (locked.getSeconds() + 59) / 60);
            response.setHeader("Retry-After", String.valueOf(locked.getSeconds()));
            showForm(request, response,
                    "Too many failed attempts. Try again in " + minutes
                            + (minutes == 1 ? " minute." : " minutes."),
                    429);
            return;
        }

        Optional<User> user = AccountService.authenticate(email, password);
        if (user.isEmpty()) {
            THROTTLE.recordFailure(key);
            // One message for "no such email" and "wrong password" so emails can't be probed.
            showForm(request, response,
                    "That email and password don't match. Check both and try again.",
                    HttpServletResponse.SC_OK);
            return;
        }

        THROTTLE.reset(key);
        HttpSession old = request.getSession(false);
        if (old != null) {
            old.invalidate();                 // new session id on sign-in prevents session fixation
        }
        request.getSession(true).setAttribute(SessionKeys.USER, user.get());
        response.sendRedirect(request.getContextPath() + "/dashboard");
    }

    private void showForm(HttpServletRequest request, HttpServletResponse response,
                          String message, int status) throws ServletException, IOException {
        response.setStatus(status);
        response.setHeader("Cache-Control", "no-store");
        request.setAttribute("csrfToken", CsrfTokens.token(request.getSession(true)));
        request.setAttribute("services", ServiceCatalogue.all());
        request.setAttribute("message", message);
        request.getRequestDispatcher(VIEW).forward(request, response);
    }
}
