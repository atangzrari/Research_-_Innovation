package com.stride.model;

/** A signed-in person. Deliberately holds no password data, so it is safe to keep in the session. */
public class User {

    private final int userId;
    private final String firstName;
    private final String lastName;
    private final String email;
    private final Role role;

    public User(int userId, String firstName, String lastName, String email, Role role) {
        this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.role = role;
    }

    public int getUserId() { return userId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getFullName() { return firstName + " " + lastName; }
    /** Two capital letters for the round avatar, e.g. "DS". */
    public String getInitials() {
        String f = firstName.isEmpty() ? "" : firstName.substring(0, 1);
        String l = lastName.isEmpty() ? "" : lastName.substring(0, 1);
        return (f + l).toUpperCase();
    }
    public String getEmail() { return email; }
    public Role getRole() { return role; }
}
