package com.stride.model;

import java.time.DayOfWeek;
import java.time.LocalTime;

/** One scheduled teaching slot: a module in a room at a time on a weekday. */
public class TimetableEntry {

    private final DayOfWeek day;
    private final LocalTime start;
    private final LocalTime end;
    private final String moduleCode;
    private final String moduleName;
    private final String room;

    public TimetableEntry(DayOfWeek day, LocalTime start, LocalTime end,
                          String moduleCode, String moduleName, String room) {
        this.day = day;
        this.start = start;
        this.end = end;
        this.moduleCode = moduleCode;
        this.moduleName = moduleName;
        this.room = room;
    }

    public DayOfWeek getDay() { return day; }
    public LocalTime getStart() { return start; }
    public LocalTime getEnd() { return end; }
    public String getModuleCode() { return moduleCode; }
    public String getModuleName() { return moduleName; }
    public String getRoom() { return room; }

    /** True if this slot is on {@code d} and overlaps the interval [from, to). */
    public boolean overlaps(DayOfWeek d, LocalTime from, LocalTime to) {
        return day == d && start.isBefore(to) && from.isBefore(end);
    }
}
