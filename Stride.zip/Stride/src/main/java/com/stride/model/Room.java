package com.stride.model;

public class Room {
    private final String name;
    private final String building;
    private final int capacity;

    public Room(String name, String building, int capacity) {
        this.name = name;
        this.building = building;
        this.capacity = capacity;
    }

    public String getName() { return name; }
    public String getBuilding() { return building; }
    public int getCapacity() { return capacity; }
}
