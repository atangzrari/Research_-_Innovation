package com.stride.model;

public enum Role {
    STUDENT("Student"),
    LECTURER("Lecturer"),
    ADMINISTRATOR("Administrator");

    private final String label;

    Role(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
