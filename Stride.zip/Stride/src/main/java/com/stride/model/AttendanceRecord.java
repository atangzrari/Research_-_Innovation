package com.stride.model;

public class AttendanceRecord {
    private final String moduleCode;
    private final String moduleName;
    private final int attended;
    private final int total;

    public AttendanceRecord(String moduleCode, String moduleName, int attended, int total) {
        this.moduleCode = moduleCode;
        this.moduleName = moduleName;
        this.attended = attended;
        this.total = total;
    }

    public String getModuleCode() { return moduleCode; }
    public String getModuleName() { return moduleName; }
    public int getAttended() { return attended; }
    public int getTotal() { return total; }
    public int getPercent() { return total == 0 ? 0 : Math.round(100f * attended / total); }
}
