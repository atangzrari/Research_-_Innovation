package com.stride.model;

/** A demo account's sign-in details, used to seed the built-in accounts. */
public class DemoLogin {
    private final User user;
    private final String password;

    public DemoLogin(User user, String password) {
        this.user = user;
        this.password = password;
    }

    public User getUser() { return user; }
    public String getRoleLabel() { return user.getRole().getLabel(); }
    public String getEmail() { return user.getEmail(); }
    public String getPassword() { return password; }
}
