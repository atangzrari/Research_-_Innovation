package com.stride.model;

public class Announcement {
    private final String title;
    private final String body;
    private final String author;
    private final String postedOn;

    public Announcement(String title, String body, String author, String postedOn) {
        this.title = title;
        this.body = body;
        this.author = author;
        this.postedOn = postedOn;
    }

    public String getTitle() { return title; }
    public String getBody() { return body; }
    public String getAuthor() { return author; }
    public String getPostedOn() { return postedOn; }
}
