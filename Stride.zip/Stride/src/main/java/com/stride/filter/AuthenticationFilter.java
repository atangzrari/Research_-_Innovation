package com.stride.filter;

import com.stride.util.SessionKeys;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * The single guard in front of every page. Mapped to /* in web.xml.
 * /login and static assets are public; everything else needs a signed-in user in the session.
 */
public class AuthenticationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String path = pathOf(request);
        HttpSession session = request.getSession(false);
        boolean signedIn = session != null && session.getAttribute(SessionKeys.USER) != null;

        if (path.equals("/login") || path.startsWith("/assets/")) {
            chain.doFilter(request, response);
            return;
        }
        if (path.equals("/") || path.isEmpty()) {
            response.sendRedirect(request.getContextPath() + (signedIn ? "/dashboard" : "/login"));
            return;
        }
        if (!signedIn) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        // Signed-in pages must not be cached, so Back after sign-out shows nothing private.
        response.setHeader("Cache-Control", "no-store");
        chain.doFilter(request, response);
    }

    /** Request path without the context path or a ;jsessionid parameter. */
    private static String pathOf(HttpServletRequest request) {
        String path = request.getRequestURI().substring(request.getContextPath().length());
        int semicolon = path.indexOf(';');
        return semicolon >= 0 ? path.substring(0, semicolon) : path;
    }
}
