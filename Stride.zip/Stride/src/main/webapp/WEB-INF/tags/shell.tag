<%@ tag body-content="scriptless" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ attribute name="title" required="true" %>
<%@ attribute name="active" required="true" %>
<c:url var="homeUrl" value="/dashboard"/>
<c:url var="classesUrl" value="/classes"/>
<c:url var="noticesUrl" value="/notices"/>
<c:url var="attendanceUrl" value="/attendance"/>
<c:url var="sitesUrl" value="/sites"/>
<c:url var="helpUrl" value="/help"/>
<c:url var="logoutUrl" value="/logout"/>
<c:url var="cssUrl" value="/assets/css/stride.css"/>
<c:url var="iconUrl" value="/assets/img/favicon.svg"/>
<c:url var="sizeJs" value="/assets/js/size.js"/>
<c:url var="appJs" value="/assets/js/app.js"/>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#ABCAE9">
    <title><c:out value="${title}"/> | Stride</title>
    <link rel="icon" href="${iconUrl}" type="image/svg+xml">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="${cssUrl}">
    <script src="${sizeJs}"></script>
    <script src="${appJs}" defer></script>
</head>
<body>
<%-- icon sprite: drawn once, reused with <use href="#i-name"> --%>
<svg class="sprite" width="0" height="0" aria-hidden="true" focusable="false">
    <defs>
        <symbol id="i-home" viewBox="0 0 24 24"><path d="M3 11l9-8 9 8M5 10v10h14V10M10 20v-6h4v6"/></symbol>
        <symbol id="i-classes" viewBox="0 0 24 24"><path d="M4 6h16v14H4zM4 10h16M8 3v4M16 3v4"/></symbol>
        <symbol id="i-notices" viewBox="0 0 24 24"><path d="M6 9a6 6 0 0112 0c0 6 2 7 2 7H4s2-1 2-7zM10 20a2 2 0 004 0"/></symbol>
        <symbol id="i-attendance" viewBox="0 0 24 24"><path d="M12 21a9 9 0 100-18 9 9 0 000 18zM8 12l3 3 5-6"/></symbol>
        <symbol id="i-sites" viewBox="0 0 24 24"><path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/></symbol>
        <symbol id="i-help" viewBox="0 0 24 24"><path d="M12 21a9 9 0 100-18 9 9 0 000 18zM9.5 9.5a2.5 2.5 0 114 2c-1 .7-1.5 1.2-1.5 2.5M12 17h.01"/></symbol>
        <symbol id="i-search" viewBox="0 0 24 24"><path d="M11 18a7 7 0 100-14 7 7 0 000 14zM21 21l-5-5"/></symbol>
        <symbol id="i-external" viewBox="0 0 24 24"><path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/></symbol>
        <symbol id="i-gradebook" viewBox="0 0 24 24"><path d="M9 4h6v3H9zM6 5h12v16H6zM9 12h6M9 16h4"/></symbol>
        <symbol id="i-moodle" viewBox="0 0 24 24"><path d="M12 6c-2-2-5-2.5-8-2v14c3-.5 6 0 8 2 2-2 5-2.5 8-2V4c-3-.5-6 0-8 2zM12 6v14"/></symbol>
        <symbol id="i-timetable" viewBox="0 0 24 24"><path d="M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2"/></symbol>
        <symbol id="i-library" viewBox="0 0 24 24"><path d="M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3zM5 17a3 3 0 013-3h11"/></symbol>
        <symbol id="i-thuto" viewBox="0 0 24 24"><path d="M7 3h8l4 4v14H7zM14 3v5h5M10 14h6M10 17h4"/></symbol>
    </defs>
</svg>

<a class="skip" href="#main">Skip to main content</a>

<div class="app">
    <nav class="side" aria-label="Main">
        <a class="brand" href="${homeUrl}" aria-label="Stride home">
            <svg viewBox="0 0 32 32" aria-hidden="true" focusable="false">
                <rect x="2" y="20" width="8" height="10" fill="#000"/>
                <rect x="12" y="12" width="8" height="18" fill="#000"/>
                <rect x="22" y="4" width="8" height="26" fill="#000"/>
            </svg>
            <span>Stride</span>
        </a>
        <ul class="nav">
            <li><a href="${homeUrl}" ${active == 'home' ? 'aria-current="page"' : ''}>
                <svg class="ico" aria-hidden="true" focusable="false"><use href="#i-home"/></svg><span>Home</span></a></li>
            <li><a href="${classesUrl}" ${active == 'classes' ? 'aria-current="page"' : ''}>
                <svg class="ico" aria-hidden="true" focusable="false"><use href="#i-classes"/></svg><span>My classes</span></a></li>
            <li><a href="${noticesUrl}" ${active == 'notices' ? 'aria-current="page"' : ''}>
                <svg class="ico" aria-hidden="true" focusable="false"><use href="#i-notices"/></svg><span>Notices</span></a></li>
            <li><a href="${attendanceUrl}" ${active == 'attendance' ? 'aria-current="page"' : ''}>
                <svg class="ico" aria-hidden="true" focusable="false"><use href="#i-attendance"/></svg><span>Attendance</span></a></li>
            <li><a href="${sitesUrl}" ${active == 'sites' ? 'aria-current="page"' : ''}>
                <svg class="ico" aria-hidden="true" focusable="false"><use href="#i-sites"/></svg><span>College sites</span></a></li>
        </ul>
    </nav>

    <header class="topbar">
        <a class="brand brand-small" href="${homeUrl}" aria-label="Stride home">
            <svg viewBox="0 0 32 32" aria-hidden="true" focusable="false">
                <rect x="2" y="20" width="8" height="10" fill="#000"/>
                <rect x="12" y="12" width="8" height="18" fill="#000"/>
                <rect x="22" y="4" width="8" height="26" fill="#000"/>
            </svg>
            <span>Stride</span>
        </a>

        <form class="topsearch" action="${sitesUrl}" method="get" role="search">
            <label class="visually-hidden" for="top-search">Search Stride</label>
            <svg class="ico" aria-hidden="true" focusable="false"><use href="#i-search"/></svg>
            <input id="top-search" type="search" name="q" autocomplete="off"
                   placeholder="Search, for example results or books">
            <button class="button" type="submit">Search</button>
        </form>

        <div class="top-actions">
            <div class="textsize" role="group" aria-label="Text size">
                <button type="button" class="ts ts-1" data-size="normal" aria-label="Normal text" aria-pressed="true">A</button>
                <button type="button" class="ts ts-2" data-size="large" aria-label="Large text" aria-pressed="false">A</button>
                <button type="button" class="ts ts-3" data-size="xlarge" aria-label="Extra large text" aria-pressed="false">A</button>
            </div>
            <a class="button button-quiet" href="${helpUrl}" ${active == 'help' ? 'aria-current="page"' : ''}>
                <svg class="ico" aria-hidden="true" focusable="false"><use href="#i-help"/></svg>Help</a>
            <p class="me" title="${fn:escapeXml(sessionScope.strideUser.fullName)}">
                <span class="avatar" aria-hidden="true"><c:out value="${sessionScope.strideUser.initials}"/></span>
                <span class="me-name"><c:out value="${sessionScope.strideUser.firstName}"/></span>
            </p>
            <form action="${logoutUrl}" method="post">
                <input type="hidden" name="_csrf" value="<c:out value='${csrfToken}'/>">
                <button class="button button-quiet" type="submit">Sign out</button>
            </form>
        </div>
    </header>

    <main class="content" id="main">
        <jsp:doBody/>
    </main>
</div>
</body>
</html>
