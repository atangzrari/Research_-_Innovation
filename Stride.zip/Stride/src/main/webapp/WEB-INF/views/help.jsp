<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="s" tagdir="/WEB-INF/tags" %>
<c:url var="homeUrl" value="/dashboard"/>
<s:shell title="Help" active="help">
    <header class="page-head">
        <h1>Help</h1>
        <p class="lead">Stride puts the college's websites in one place. Here is how to use it.</p>
    </header>

    <section aria-labelledby="steps-title">
        <h2 id="steps-title">Three steps</h2>
        <ol class="steps">
            <li><strong>Go to Home.</strong> Press the <em>Home</em> button on the left (or at the bottom of a phone).</li>
            <li><strong>Press the big button for what you want.</strong> For example, <em>Check my results</em>.</li>
            <li><strong>A new tab opens.</strong> Sign in there with your college account. Come back to Stride by clicking its tab.</li>
        </ol>
        <a class="button" href="${homeUrl}">Go to Home</a>
    </section>

    <section aria-labelledby="faq-title">
        <h2 id="faq-title">Common questions</h2>
        <details>
            <summary>The writing is too small.</summary>
            <p>At the top of every page there are three buttons with the letter A. Press the middle one for large text, or the right one for extra large text.</p>
        </details>
        <details>
            <summary>Why do I have to sign in again on another site?</summary>
            <p>Stride opens the college's own websites. Each one keeps its own sign-in, so use the same details you always use for that site.</p>
        </details>
        <details>
            <summary>How do I find something quickly?</summary>
            <p>Type a word, such as <em>results</em> or <em>books</em>, in the box at the top and press Search.</p>
        </details>
        <details>
            <summary>How do I leave Stride safely?</summary>
            <p>Press <em>Sign out</em> at the top right. Always do this on a shared computer.</p>
        </details>
        <details>
            <summary>I still need help.</summary>
            <p>Ask ICT Support at the college.</p>
        </details>
    </section>
</s:shell>
