<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="s" tagdir="/WEB-INF/tags" %>
<%--@elvariable id="services" type="java.util.List<com.stride.model.CampusService>"--%>
<%--@elvariable id="query" type="java.lang.String"--%>
<%--@elvariable id="total" type="java.lang.Integer"--%>
<c:url var="sitesUrl" value="/sites"/>
<s:shell title="College sites" active="sites">
    <header class="page-head">
        <h1>College sites</h1>
        <p class="lead">
            <c:choose>
                <c:when test="${not empty query}">
                    <c:out value="${services.size()}"/> of <c:out value="${total}"/> match &ldquo;<c:out value="${query}"/>&rdquo;.
                    <a href="${sitesUrl}">Show all</a>
                </c:when>
                <c:otherwise>All the college's websites in one list. Each one opens in a new tab.</c:otherwise>
            </c:choose>
        </p>
    </header>

    <c:choose>
        <c:when test="${empty services}">
            <p class="empty-note">Nothing matches &ldquo;<c:out value="${query}"/>&rdquo;. Try a simpler word, such as results, courses, timetable, books or apply.
                <a href="${sitesUrl}">Show all sites</a></p>
        </c:when>
        <c:otherwise>
            <div class="tiles tiles-wide">
                <c:forEach var="t" items="${services}">
                    <a class="tile" href="<c:out value='${t.url}'/>" target="_blank" rel="noopener noreferrer">
                        <span class="tile-icon"><svg class="ico" aria-hidden="true" focusable="false"><use href="#i-${t.id}"/></svg></span>
                        <span class="tile-title"><c:out value="${t.name}"/></span>
                        <span class="tile-sub"><c:out value="${t.description}"/></span>
                        <span class="tile-open">Open <c:out value="${t.name}"/>
                            <span class="visually-hidden">(opens in a new tab)</span>
                            <svg class="ico" aria-hidden="true" focusable="false"><use href="#i-external"/></svg></span>
                    </a>
                </c:forEach>
            </div>
        </c:otherwise>
    </c:choose>
</s:shell>
