<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="s" tagdir="/WEB-INF/tags" %>
<%--@elvariable id="announcements" type="java.util.List<com.stride.model.Announcement>"--%>
<s:shell title="Notices" active="notices">
    <header class="page-head">
        <h1>Notices</h1>
        <p class="lead">Messages from the college, newest first.</p>
        <p class="sample">Sample data</p>
    </header>

    <ul class="stream">
        <c:forEach var="a" items="${announcements}">
            <li class="post">
                <p class="avatar avatar-big" aria-hidden="true"><c:out value="${a.author.substring(0, 1)}"/></p>
                <div class="post-body">
                    <p class="post-meta"><strong><c:out value="${a.author}"/></strong>, <c:out value="${a.postedOn}"/></p>
                    <h2><c:out value="${a.title}"/></h2>
                    <p><c:out value="${a.body}"/></p>
                </div>
            </li>
        </c:forEach>
    </ul>
</s:shell>
