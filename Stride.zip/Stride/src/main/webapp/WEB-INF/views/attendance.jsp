<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="s" tagdir="/WEB-INF/tags" %>
<%--@elvariable id="attendance" type="java.util.List<com.stride.model.AttendanceRecord>"--%>
<s:shell title="Attendance" active="attendance">
    <header class="page-head">
        <h1>Attendance</h1>
        <p class="lead">How many classes you have been to in each subject.</p>
        <p class="sample">Sample data</p>
    </header>

    <ul class="course-cards">
        <c:forEach var="t" items="${attendance}">
            <li class="course-card">
                <p class="course-code"><c:out value="${t.moduleCode}"/></p>
                <h2><c:out value="${t.moduleName}"/></h2>
                <p class="percent"><c:out value="${t.percent}"/>%</p>
                <progress value="${t.attended}" max="${t.total}"
                          aria-label="Attendance for ${t.moduleName}"><c:out value="${t.percent}"/>%</progress>
                <p>You went to <strong><c:out value="${t.attended}"/> of <c:out value="${t.total}"/></strong> classes.</p>
            </li>
        </c:forEach>
    </ul>
</s:shell>
