<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="s" tagdir="/WEB-INF/tags" %>
<%--@elvariable id="today" type="java.lang.String"--%>
<%--@elvariable id="todayClasses" type="java.util.List<com.stride.model.TodayClass>"--%>
<%--@elvariable id="freeRooms" type="java.util.List<com.stride.model.FreeRoom>"--%>
<%--@elvariable id="roomsOpen" type="java.lang.Boolean"--%>
<s:shell title="My classes" active="classes">
    <header class="page-head">
        <p class="muted"><c:out value="${today}"/></p>
        <h1>My classes</h1>
        <p class="lead">Everything you have on today, in time order.</p>
        <p class="sample">Sample data</p>
    </header>

    <section aria-labelledby="today-title">
        <h2 id="today-title">Today</h2>
        <c:choose>
            <c:when test="${empty todayClasses}">
                <p class="empty-note">You have no classes today.</p>
            </c:when>
            <c:otherwise>
                <ul class="class-cards">
                    <c:forEach var="k" items="${todayClasses}">
                        <li class="class-card${k.now ? ' class-now' : ''}">
                            <div class="class-top">
                                <p class="class-code"><c:out value="${k.moduleCode}"/></p>
                                <p class="badge${k.now ? ' badge-now' : ''}"><c:out value="${k.statusLabel}"/></p>
                            </div>
                            <div class="class-body">
                                <h3><c:out value="${k.moduleName}"/></h3>
                                <p class="class-time"><c:out value="${k.startText}"/> to <c:out value="${k.endText}"/></p>
                                <p class="muted">Room: <c:out value="${k.room}"/></p>
                            </div>
                        </li>
                    </c:forEach>
                </ul>
            </c:otherwise>
        </c:choose>
    </section>

    <section aria-labelledby="rooms-title">
        <h2 id="rooms-title">Rooms you can use right now</h2>
        <c:choose>
            <c:when test="${not roomsOpen}"><p class="empty-note">Rooms are listed between 07:00 and 18:00.</p></c:when>
            <c:when test="${empty freeRooms}"><p class="empty-note">Every room is in use right now.</p></c:when>
            <c:otherwise>
                <ul class="room-list">
                    <c:forEach var="r" items="${freeRooms}">
                        <li>
                            <p class="room-name"><c:out value="${r.name}"/></p>
                            <p class="muted"><c:out value="${r.building}"/>, seats <c:out value="${r.capacity}"/></p>
                            <p><strong>Free until <c:out value="${r.freeUntil}"/></strong></p>
                        </li>
                    </c:forEach>
                </ul>
            </c:otherwise>
        </c:choose>
    </section>
</s:shell>
