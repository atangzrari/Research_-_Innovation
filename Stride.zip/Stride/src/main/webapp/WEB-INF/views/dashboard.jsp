<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="s" tagdir="/WEB-INF/tags" %>
<%--@elvariable id="greeting" type="java.lang.String"--%>
<%--@elvariable id="today" type="java.lang.String"--%>
<%--@elvariable id="tiles" type="java.util.List<com.stride.model.CampusService>"--%>
<%--@elvariable id="classCount" type="java.lang.Integer"--%>
<%--@elvariable id="nextClass" type="com.stride.model.TodayClass"--%>
<%--@elvariable id="latestNotice" type="com.stride.model.Announcement"--%>
<c:url var="classesUrl" value="/classes"/>
<c:url var="noticesUrl" value="/notices"/>
<s:shell title="Home" active="home">
    <header class="page-head">
        <p class="muted"><c:out value="${today}"/></p>
        <h1><c:out value="${greeting}"/>, <c:out value="${sessionScope.strideUser.firstName}"/>.</h1>
        <p class="lead">What would you like to do today?</p>
    </header>

    <section aria-labelledby="do-title">
        <h2 id="do-title" class="visually-hidden">Things you can do</h2>
        <div class="tiles">
            <c:forEach var="t" items="${tiles}">
                <a class="tile" href="<c:out value='${t.url}'/>" target="_blank" rel="noopener noreferrer">
                    <span class="tile-icon"><svg class="ico" aria-hidden="true" focusable="false"><use href="#i-${t.id}"/></svg></span>
                    <span class="tile-title"><c:out value="${t.task}"/></span>
                    <span class="tile-sub">Opens <c:out value="${t.name}"/> in a new tab
                        <span class="visually-hidden">(opens in a new tab)</span></span>
                </a>
            </c:forEach>
        </div>
    </section>

    <div class="glance">
        <section class="card" aria-labelledby="glance-title">
            <div class="card-head">
                <h2 id="glance-title">Today at a glance</h2>
                <p class="sample">Sample data</p>
            </div>
            <div class="card-body">
                <c:choose>
                    <c:when test="${classCount == 0}">
                        <p class="big">No classes today.</p>
                        <p class="muted">Enjoy the day.</p>
                    </c:when>
                    <c:otherwise>
                        <p class="big">You have <c:out value="${classCount}"/> <c:out value="${classCount == 1 ? 'class' : 'classes'}"/> today.</p>
                        <c:if test="${not empty nextClass}">
                            <p><c:out value="${nextClass.now ? 'On now:' : 'Next:'}"/>
                                <strong><c:out value="${nextClass.moduleName}"/></strong>
                                at <c:out value="${nextClass.startText}"/> in <c:out value="${nextClass.room}"/>.</p>
                        </c:if>
                        <c:if test="${empty nextClass}"><p class="muted">All of today's classes are finished.</p></c:if>
                    </c:otherwise>
                </c:choose>
                <a class="button" href="${classesUrl}">See my classes</a>
            </div>
        </section>

        <section class="card" aria-labelledby="notice-title">
            <div class="card-head">
                <h2 id="notice-title">Latest notice</h2>
                <p class="sample">Sample data</p>
            </div>
            <div class="card-body">
                <p class="big"><c:out value="${latestNotice.title}"/></p>
                <p><c:out value="${latestNotice.body}"/></p>
                <p class="muted">From <c:out value="${latestNotice.author}"/>, <c:out value="${latestNotice.postedOn}"/></p>
                <a class="button" href="${noticesUrl}">Read all notices</a>
            </div>
        </section>
    </div>
</s:shell>
