# Stride

One sign-in and one home page for the college sites students use every day:
Gradebook, Moodle, PrimeTimetable, the digital library (EBSCO) and ThutoAcademics.
Java 17, Jakarta Servlet 6.1 / JSP, Tomcat 11, Maven. No database yet.

## Run it (IntelliJ)
1. **File > Open** the `Stride` folder and let Maven import `pom.xml`.
2. **Run > Edit Configurations > + > Tomcat Server > Local**, pick Tomcat 11.
3. **Deployment** tab: **+ > Artifact > Stride:war exploded**, set *Application context* to `/`.
   (No artifact listed? **File > Project Structure > Artifacts > + > Web Application: Exploded > From Modules**.)
4. Run, then open http://localhost:8080/ (it redirects to the sign-in page).

## Demo accounts (made-up, for testing only)
These work on the sign-in page but are no longer shown on it. Replace them with real accounts before real use.

| Role | Email | Password |
|---|---|---|
| Student | student@stride.test | student123 |
| Lecturer | lecturer@stride.test | lecturer123 |
| Administrator | admin@stride.test | admin123 |

## What the pages are (mixing Slack, Teams, Moodle and Google Classroom)
- **Sidebar (Slack/Teams):** Home, My classes, Notices, Attendance, College sites. On a phone it becomes a bottom tab bar.
- **Top bar:** search, three text-size buttons, Help, your name and Sign out.
- **Home (Classroom-style cards):** big plain-language buttons (Check my results, Open my courses, See the full timetable, Find a book or article, Apply to study), plus "Today at a glance" and the latest notice.
- **My classes:** today's classes as cards, and rooms you can use right now.
- **Notices:** a Classroom-style stream of messages.
- **Attendance:** Moodle-style course cards with a bar and percentage.
- **College sites:** the five sites with search. **Help:** three steps and common questions.

Easy-to-use choices: 18px base text (up to 23px), buttons at least 48px tall, icon plus word on every menu item, plain wording, one clear action per card, no hidden menus.

## Sample data
All of it is made up and lives in `data/DummyData.java`; each panel is labelled "Sample data".
- **Today's classes:** a Monday to Saturday timetable, marked finished, in progress or later using the time in Gaborone.
- **Free rooms:** worked out from the timetable (a room is free only if no class overlaps this minute; rooms are listed 07:00 to 18:00).
- **Notices** and **attendance:** four sample notices; attended versus total classes for five modules.

## Structure
```
src/main/java/com/stride/
  model/       User, Role, CampusService          plain data classes
  data/        ServiceCatalogue, DummyData        the five sites + search; sample timetable, rooms, notices
  service/     AccountService, ScheduleService    sign-in check; today's classes and free-room rules
  security/    PasswordHasher, LoginThrottle, CsrfTokens
  filter/      SecurityHeadersFilter, AuthenticationFilter
  controller/  LoginController, PortalController (all signed-in pages), LogoutController
  util/        SessionKeys
src/main/webapp/
  WEB-INF/web.xml            filters, session cookie, error pages, "no scriptlets" rule
  WEB-INF/views/             login, dashboard, classes, notices, attendance, sites, help, error  (.jsp)
  WEB-INF/tags/shell.tag     the shared page frame (sidebar + top bar)
  assets/                    css, js, favicon (public)
```
Request flow: **filter -> controller -> view**. Views contain no Java code (`scripting-invalid` is on).

## Practices applied
- **Passwords:** salted PBKDF2-HMAC-SHA256 (600,000 rounds), constant-time compare, equal timing for unknown emails.
- **Sessions:** new session id at sign-in (fixation), HttpOnly + SameSite=Lax cookie, 30-minute timeout, `no-store` on signed-in pages.
- **CSRF:** synchroniser token on sign-in and sign-out; sign-out is POST-only.
- **Brute force:** 5 failed attempts per email locks that email for 5 minutes (HTTP 429).
- **Headers:** Content-Security-Policy (own scripts/styles + Google Fonts only), nosniff, frame-ancestors none, Referrer-Policy, Permissions-Policy.
- **Output:** every value printed with `<c:out>` (XSS); external links use `rel="noopener noreferrer"`.
- **Accessibility (WCAG 2.2 AA aims):** skip links, landmarks, labelled fields, `role="alert"/"status"`, visible focus, errors not shown by colour alone, black on lavender and white contrast above 7:1, keyboard shortcut `/` for search, reduced-motion respected, works without JavaScript.
- **Errors:** friendly 403/404/500 page, no stack traces.

## Before real use
- Set `<secure>true</secure>` in `web.xml` and serve over HTTPS.
- Replace `AccountService` with a database-backed DAO or the college's single sign-on.
- Stride only links out: each college site keeps its own sign-in, and those sites cannot be embedded in Stride.
- Check the ThutoAcademics address in `ServiceCatalogue.java` (it is spelled `thitoacademics` in the brief).
